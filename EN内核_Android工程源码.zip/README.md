# EN内核 Android 项目

这是 EN内核 的 Android 原生基础工程（Kotlin）。

## 当前包含
- EN内核首页与基础视觉框架
- 工具中心入口卡片
- 版本信息区域
- Android 6.0（API 23）及以上的基础配置

## 构建 APK
1. 在电脑安装 Android Studio（建议使用稳定版）。
2. 解压本项目并在 Android Studio 中选择 Open，打开项目根目录。
3. 等待 Gradle 同步完成，并安装 Android SDK 35。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常会生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## 说明
当前是可继续开发的基础工程，不是已编译的 APK。FPS、游戏管理等卡片目前是模块占位入口。
后续可以接入合法、透明且获得授权的游戏工具；不包含绕过游戏安全机制、未授权注入或作弊内核。
