package com.en.kernel

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 13, 25)
    private val panel = Color.rgb(27, 28, 48)
    private val accent = Color.rgb(164, 119, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        content.addView(label("EN KERNEL", 13, accent, true))
        content.addView(label("EN内核", 34, Color.WHITE, true).apply {
            setPadding(0, 5, 0, 2)
        })
        content.addView(label("GAME TOOLKIT  ·  VERSION 1.0.0", 11, 0xFF9B9BB5.toInt(), false))
        content.addView(space(22))

        val welcome = card()
        welcome.addView(label("欢迎使用 EN 内核", 20, Color.WHITE, true))
        welcome.addView(label("你的专属游戏工具箱已经准备就绪。", 13, 0xFFB9B8CC.toInt(), false))
        content.addView(welcome)
        content.addView(space(18))

        content.addView(label("工具中心", 19, Color.WHITE, true))
        content.addView(space(10))
        content.addView(toolCard("FPS 信息", "查看应用内性能状态与帧率说明", "查看") {
            Toast.makeText(this, "FPS 监测模块将在后续版本接入。", Toast.LENGTH_SHORT).show()
        })
        content.addView(space(10))
        content.addView(toolCard("游戏管理", "整理和快捷打开设备中已安装的游戏", "进入") {
            Toast.makeText(this, "游戏管理模块将在后续版本接入。", Toast.LENGTH_SHORT).show()
        })
        content.addView(space(10))
        content.addView(toolCard("实用工具", "预留安全、合规的游戏辅助工具入口", "打开") {
            Toast.makeText(this, "工具模块将在后续版本接入。", Toast.LENGTH_SHORT).show()
        })
        content.addView(space(18))

        val settings = card()
        settings.addView(label("设置与版本", 17, Color.WHITE, true))
        settings.addView(label("版本：1.0.0\n当前为基础框架预览版。", 13, 0xFFB9B8CC.toInt(), false))
        content.addView(settings)
        content.addView(space(20))
        content.addView(label("EN KERNEL  ·  BUILT FOR YOUR OWN PROJECT", 10, 0xFF77778F.toInt(), false).apply {
            gravity = Gravity.CENTER
        })

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun space(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, h)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 17, 18, 17)
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF292943.toInt(), panel)
        ).apply { cornerRadius = 24f; setStroke(1, 0xFF51466F.toInt()) }
    }

    private fun toolCard(title: String, desc: String, action: String, onClick: () -> Unit): LinearLayout {
        val box = card()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 17, Color.WHITE, true))
        texts.addView(label(desc, 12, 0xFFB9B8CC.toInt(), false))
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val btn = Button(this).apply {
            text = action
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 18f
                setColor(0xFF7654C8.toInt())
            }
            setOnClickListener { onClick() }
        }
        row.addView(btn)
        box.addView(row)
        return box
    }
}
